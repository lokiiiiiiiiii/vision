import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread("girl.png")
img1 = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
equ = cv2.equalizeHist(img1)
res = np.hstack((img1,equ))
cv2.imshow("image",res)
hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
hist = cv2.calcHist([hsv],[0,1],None,[190,256],[0,180,0,256])

plt.imshow(hist,interpolation = 'nearest')
plt.show( )

