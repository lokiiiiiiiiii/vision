import cv2
import numpy as np

img = cv2.imread("label.jpg",0)#灰度读取
core = np.ones((5,5),np.uint8)#使用（5X5内核）
ret,erzhihua = cv2.threshold(img,160,255,0)
result = cv2.morphologyEx(erzhihua,cv2.MORPH_CLOSE,core)#闭运算
img2 = cv2.resize(result,dsize=(768,576))#按比例调整图片大小
cv2.imshow("image",img2)
cv2.waitKey(0)