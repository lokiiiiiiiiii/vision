import cv2
import numpy as np
import math

def draw(img,temp):#运用模板匹配找寻（checkerboard .png）黑白子，计算黑子之间的距离与白字之间的距离，得到两个最大值，运用直线画出连接两段距离最大的黑子和白子的直线
    max = 0
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    w, h = temp.shape[::-1]
    res = cv2.matchTemplate(gray, temp, cv2.TM_CCOEFF_NORMED)
    threshold = 0.7
    loc = np.where(res >= threshold)
    for pt in zip(*loc[::-1]):
        cv2.rectangle(img, pt, (pt[0] + w, pt[1] + h), (0, 255, 0), 1)
    for pt in zip(*loc[::-1]):
        x1 = pt[0] + w / 2.0
        y1 = pt[1] + h / 2.0
        for tp in zip(*loc[::-1]):
            x2 = tp[0] + w / 2.0
            y2 = tp[1] + h / 2.0
            minus1 = x1 - x2
            minus2 = y1 - y2
            part1 = math.pow(minus1, 2)
            part2 = math.pow(minus2, 2)
            dis = int(math.sqrt(part1 + part2))
            if dis > max:
                max = dis
                dian1 = (int(x2), int(y2))
                dian2 = (int(x1), int(y1))
    cv2.line(img, dian1, dian2, (255, 0, 0), 5)

img = cv2.imread('checkerboard .png')
white = cv2.imread('baizi.jpg', 0)
black = cv2.imread('heizi.jpg', 0)
draw(img,white)
draw(img,black)

#运用hough直线检验出棋盘的中本来的黑线，以不同颜色画出。
img2 = img.copy()
gray = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray,50,150,apertureSize = 3)
lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 80, minLineLength=30, maxLineGap=10)
for line in lines:
    x1 = line[0][0]
    y1 = line[0][1]
    x2 = line[0][2]
    y2 = line[0][3]
    cv2.line(img, (x1, y1), (x2, y2), (0, 0, 255), 2)

cv2.imshow('qipan',img)
cv2.waitKey(0)
cv2.destroyAllWindows()




