import cv2
import numpy as np

#读取图像
img = cv2.imread('red block.png')
#转换颜色空间BGR到HSV
hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
#定义HSV中蓝色的范围
dired = np.array([127,50,50])
gaored = np.array([200,255,255])
#设置HSV的阈值使得只取蓝色
mask = cv2.inRange(hsv,dired,gaored)
#将掩膜和图像逐像素相加
res = cv2.bitwise_and(img,img,mask=mask)

rows,cols = res.shape[0:2]
#opencv旋转函数**cv.getRotationMatrix2D**
M = cv2.getRotationMatrix2D(((cols)/2.0,(rows)/2.0),-19,1)
des = cv2.warpAffine(res,M,(cols,rows))
#结果展示
cv2.imshow('image',des)
k = cv2.waitKey(0)
cv2.destroyAllWindows()


