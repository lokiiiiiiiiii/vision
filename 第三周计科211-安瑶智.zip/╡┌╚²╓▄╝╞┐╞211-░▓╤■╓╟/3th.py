import numpy as np
import cv2
from matplotlib import pyplot as plt

window_name='image'
track_bar_name='s'

drawing = False
ix,iy=0,0

def nothing(x):
    pass

def mix(name,img1,img2,track):#图像混合函数
    a = float(cv2.getTrackbarPos(track,name)/100)
    mixtupian = cv2.addWeighted(img1,a,img2,1.0-a,0)
    return mixtupian

def print_img(img):
    print(img.shape)#行、列、通道
    print(img.size)#像素总数
    print(img.dtype)#图像数据类型

def draw_rectangle(event,x,y,flags,param):#设置回调函数画出红色矩形
    global ix,iy,drawing
    if event==cv2.EVENT_LBUTTONDOWN:
        drawing = True
        ix,iy=x,y
    elif event==cv2.EVENT_LBUTTONUP:
        drawing = False
        cv2.rectangle(tupian1, (ix, iy), (x, y), (0, 0, 255), 5)

cv2.namedWindow(window_name)
tupian1 = cv2.imread("football.png")#读取图片1
tupian2 = cv2.imread("red block.png")#读取图片2

s = cv2.createTrackbar(track_bar_name,window_name,0,100,nothing)#设置滚动条

print_img(tupian1)#输出图片1的信息
print_img(tupian2)#输出图片2的信息

tupian2_1 = cv2.resize(tupian2,dsize=(tupian1.shape[1],tupian1.shape[0]))#将图片2的大小改为与图片1相等的便于下一步混合


cv2.setMouseCallback(window_name,draw_rectangle)#函数的调用
while True:
    cv2.imshow(window_name,mix(window_name,tupian1,tupian2_1,track_bar_name))
    k = cv2.waitKey(1)
    if k == 27 & 0xFF:
        break
cv2.destroyAllWindows()



