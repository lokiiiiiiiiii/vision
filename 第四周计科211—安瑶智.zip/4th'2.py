import cv2
import numpy as np

img = cv2.imread("gun.jpg")#读取图像
img = cv2.resize(img,dsize=(432,576))#按比例调整图片大小
hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)#转化为hsv通道

#获取图像阈值，创建掩膜
xiaxian = np.array([0,153,28])#设置下限
shangxian = np.array([80,232,197])#设置上限
mask = cv2.inRange(hsv,xiaxian,shangxian)
img1 = cv2.bitwise_and(img,img,mask=mask)

img2 = cv2.cvtColor(img1,cv2.COLOR_BGR2GRAY)#灰度处理
ret,yuzhi = cv2.threshold(img2,0,255,0)#二值化处理
contours,hierarchy = cv2.findContours(yuzhi,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
contours = sorted(contours,key=cv2.contourArea,reverse =True)[:5]
cnt = contours[0]

#绘制矩形
x,y,k,c = cv2.boundingRect(cnt)
img = cv2.rectangle(img,(x,y),(x+k,y+c),(0,255,0),2)
print("矩形长为：")
print(c)
print("矩形宽为：")
print(k)
print("矩形中心点为：")
print((x,y))

#绘制圆形
(a,b),radius = cv2.minEnclosingCircle(cnt)
radius = int(radius)
a = int(a)
b = int(b)
img = cv2.circle(img,(a,b),radius,(0,255,0),2)
print("圆心为：")
print((a,b))

#极点
leftmost = tuple(cnt[cnt[:,:,0].argmin()][0])
rightmost = tuple(cnt[cnt[:,:,0].argmax()][0])
topmost = tuple(cnt[cnt[:,:,1].argmin()][0])
bottommost = tuple(cnt[cnt[:,:,1].argmax()][0])
print("极点为")
print(leftmost)
print(rightmost)
print(topmost)
print(bottommost)
cv2.imshow('image',img)
cv2.waitKey(0)