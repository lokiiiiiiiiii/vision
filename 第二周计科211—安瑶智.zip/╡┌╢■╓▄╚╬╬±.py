import cv2
import numpy as np

def nothing(x):
    pass

drawing_1=False#鼠标左键按下为Ture
drawing_2=False#鼠标右键按下为Ture
mode=True
ix,iy=0,0
#创建回调函数
def huatu(event,x,y,flags,param):
    r=cv2.getTrackbarPos('R',"image")
    g=cv2.getTrackbarPos('G',"image")
    b=cv2.getTrackbarPos('B',"image")
    color=(b,g,r)#滑动条绑定color“bgr"
#定义全局变量
    global ix,iy,drawing_1,drawing_2,mode
#右键画圆
    if event==cv2.EVENT_RBUTTONDOWN:
        drawing_2=True
        ix,iy=x,y
    elif event==cv2.EVENT_MOUSEMOVE:
        if drawing_2==True:
            cv2.circle(img, (x, y), 25, color, -1)
    elif event==cv2.EVENT_RBUTTONUP:
        drawing_2=False

#左键画矩形 按1画填充矩形 按2画边框矩形
    if event==cv2.EVENT_LBUTTONDOWN:
        drawing_1=True
        ix,iy=x,y
    elif event==cv2.EVENT_MOUSEMOVE:
         if drawing_1==True:
             if mode==True:
                 cv2.rectangle(img,(ix,iy),(x,y),color,-1)

    elif event==cv2.EVENT_LBUTTONUP:
        if mode==False:
                cv2.rectangle(img,(ix,iy),(x,y),color,1)

        drawing_1=False
img=np.zeros((512,512,3),np.uint8)+255#创建白色画布
cv2.namedWindow('image')
cv2.createTrackbar('R','image',0,255,nothing)
cv2.createTrackbar('G','image',0,255,nothing)
cv2.createTrackbar('B','image',0,255,nothing)#滑动条
cv2.setMouseCallback('image',huatu)
while(1):
    cv2.imshow('image',img)
    k=cv2.waitKey(1)&0xFF
    if k==ord('1'):
        mode=True
    elif k==ord('2'):
        mode=False
    elif k==27:
        break

